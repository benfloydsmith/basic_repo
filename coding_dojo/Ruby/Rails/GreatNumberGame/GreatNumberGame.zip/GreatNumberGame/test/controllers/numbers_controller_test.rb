require 'test_helper'

class NumbersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
