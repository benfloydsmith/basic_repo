# RubyBeltExam
Dec 22. Belt Exam Ruby
