require 'test_helper'

class NamesHelperTest < ActionView::TestCase
end
