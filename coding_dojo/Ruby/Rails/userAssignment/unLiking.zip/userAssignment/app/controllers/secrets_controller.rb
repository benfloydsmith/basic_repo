class SecretsController < ApplicationController
	before_action :require_login, only: [:show, :create, :delete]
	def show
		@secret = Secret.all
	end
	def create
		secret = Secret.new(user: current_user, content: params[:content])
		if secret.save
			flash[:success] = "Saved Secret to User"
			redirect_to "/users/#{session[:user_id]}"
		else
			flash[:errors] = user.errors.full_messages
			redirect_to '/users/new'
		end
	end
	def delete
		secret = Secret.find(params[:id])
		secret.destroy if secret.user == current_user
		redirect_to "/users/#{session[:user_id]}"
	end
end
