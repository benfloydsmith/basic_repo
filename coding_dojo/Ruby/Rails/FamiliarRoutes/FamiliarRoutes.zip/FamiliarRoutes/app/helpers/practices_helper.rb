module PracticesHelper
end
