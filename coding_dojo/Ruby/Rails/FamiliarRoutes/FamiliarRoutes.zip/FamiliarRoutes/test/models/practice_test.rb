require 'test_helper'

class PracticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
