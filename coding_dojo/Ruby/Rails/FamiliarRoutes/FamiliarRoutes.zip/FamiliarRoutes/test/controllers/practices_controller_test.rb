require 'test_helper'

class PracticesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
