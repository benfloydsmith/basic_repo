require 'test_helper'

class PracticesHelperTest < ActionView::TestCase
end
