class RemoveCategoryFromProduct < ActiveRecord::Migration
  def change
  end
end
